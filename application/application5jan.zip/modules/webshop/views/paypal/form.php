<html>
<head>
<title>test paypal</title>
</head>
<body>
<h1>PayPal Library for Code Igniter</h1>

<?=$paypal_form?>
</body>
</html>
