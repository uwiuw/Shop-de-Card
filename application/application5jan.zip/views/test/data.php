<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
foreach($last_ten as $row){
           echo "Title {$row->title} <br />";
        }
?>
