<?php
if ($this->session->flashdata('conf_msg')) {
    echo "<div class='status_box'>";
    echo $this->session->flashdata('conf_msg');
    echo "</div>";
}
$imageinfo = $product['image'];
$image = convert_image_path(base_url() . $imageinfo);
$image = prod_dir() . $product['image_id'] . $product['extension'];
$ship_restrict = $product['ship_restrict'] != "" ? 'This Product is not available to ship to ' . $product['ship_restrict'] : "Available All State";

if ($images > 0) {
    foreach ($images as $img) {
?>
        <img src='<?= prod_dir() . $img . $product['extension'] ?>' class='prod_img' width='260' align='left'/>
<?php }
} else {
 ?>
        <img src='<?= $image ?>' alt="<?= $product['name'] ?>" class='prod_img' width='260' align='left'/>
<?php } ?>
<ul id="thumb_holder">
 <li><a href="javascript:void(0);"><img src="img/img1_thumb.jpg" alt="motherly" /> </a></li>
</ul>
<div class="product_buy">
    <div class="left_desc">
        <h2><?= $product['name'] ?></h2>
        <p>Status : <?= $product['stock_status'] ?></p>
        <p>Ship Restrictions : <?= $ship_restrict ?></p>
        <p>$ <?= $product['price']; ?></p>
        <input type="submit" value="Buy" name="add" />
    </div>
    <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>" />
    <input type="hidden" name="qty" value="1" />
    <div class="long_desc"><?= htmlspecialchars_decode($product['longdesc']); ?></div>
    <br />
</div>