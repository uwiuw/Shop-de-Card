<html>
    <title><?= $title ?></title>
    <body>
        <?php $this->load->view('shop/header');?>
        
            <div id="contents"><?= $contents ?></div>
        <div id="footer">Copyright 2008</div>
    </body>
</html>
